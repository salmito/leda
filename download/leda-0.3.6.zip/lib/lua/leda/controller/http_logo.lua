return [====[<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Created with Inkscape (http://www.inkscape.org/) -->

<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:xlink="http://www.w3.org/1999/xlink"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="1080"
   height="1080"
   id="svg1306"
   sodipodi:version="0.32"
   inkscape:version="0.48.1 r9760"
   sodipodi:docname="leda-logo.svg"
   version="1.1">
  <defs
     id="defs1308">
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6154">
      <stop
         style="stop-color:#ffe6d5;stop-opacity:1;"
         offset="0"
         id="stop6156" />
      <stop
         style="stop-color:#ffe6d5;stop-opacity:0;"
         offset="1"
         id="stop6158" />
    </linearGradient>
    <linearGradient
       id="linearGradient6146">
      <stop
         style="stop-color:#000000;stop-opacity:1"
         offset="0"
         id="stop6148" />
      <stop
         style="stop-color:#61320d;stop-opacity:0;"
         offset="1"
         id="stop6150" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6138">
      <stop
         style="stop-color:#ffb380;stop-opacity:1"
         offset="0"
         id="stop6140" />
      <stop
         style="stop-color:#803300;stop-opacity:1"
         offset="1"
         id="stop6142" />
    </linearGradient>
    <linearGradient
       id="linearGradient4641">
      <stop
         style="stop-color:#61320d;stop-opacity:1;"
         offset="0"
         id="stop4643" />
      <stop
         style="stop-color:#61320d;stop-opacity:0;"
         offset="1"
         id="stop4645" />
    </linearGradient>
    <linearGradient
       id="linearGradient4215">
      <stop
         style="stop-color:#61330d;stop-opacity:0;"
         offset="0"
         id="stop4217" />
      <stop
         style="stop-color:#7b4111;stop-opacity:0.60176992;"
         offset="1"
         id="stop4219" />
    </linearGradient>
    <linearGradient
       id="linearGradient3978">
      <stop
         style="stop-color:#ec780d;stop-opacity:1;"
         offset="0"
         id="stop3980" />
      <stop
         id="stop3986"
         offset="0.45833334"
         style="stop-color:#b56f2d;stop-opacity:1;" />
      <stop
         style="stop-color:#e08f44;stop-opacity:1;"
         offset="1"
         id="stop3982" />
    </linearGradient>
    <inkscape:perspective
       sodipodi:type="inkscape:persp3d"
       inkscape:vp_x="0 : 24 : 1"
       inkscape:vp_y="0 : 1000 : 0"
       inkscape:vp_z="48 : 24 : 1"
       inkscape:persp3d-origin="24 : 16 : 1"
       id="perspective2979" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2298"
       id="linearGradient7748"
       gradientUnits="userSpaceOnUse"
       x1="-27.006643"
       y1="-37.550461"
       x2="-34.700153"
       y2="-4.4493785" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2527"
       id="linearGradient7746"
       gradientUnits="userSpaceOnUse"
       x1="-25.137094"
       y1="-1.2491118"
       x2="-35.652866"
       y2="-24.88446" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient3478"
       id="linearGradient7744"
       gradientUnits="userSpaceOnUse"
       x1="11.149398"
       y1="-43.997444"
       x2="4.9625983"
       y2="-8.3080902" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient4829">
      <stop
         style="stop-color:#000000;stop-opacity:1;"
         offset="0"
         id="stop4831" />
      <stop
         style="stop-color:#000000;stop-opacity:0;"
         offset="1"
         id="stop4833" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient3478">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop3480" />
      <stop
         style="stop-color:#ffffff;stop-opacity:0;"
         offset="1"
         id="stop3482" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient2298">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop2300" />
      <stop
         style="stop-color:#ffffff;stop-opacity:0;"
         offset="1"
         id="stop2302" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient3347">
      <stop
         style="stop-color:#edd400;stop-opacity:1;"
         offset="0"
         id="stop3349" />
      <stop
         style="stop-color:#edd400;stop-opacity:0;"
         offset="1"
         id="stop3351" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient2527">
      <stop
         style="stop-color:#fcaf3e;stop-opacity:1;"
         offset="0"
         id="stop2529" />
      <stop
         style="stop-color:#fcaf3e;stop-opacity:0;"
         offset="1"
         id="stop2531" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient2500">
      <stop
         style="stop-color:#fce94f;stop-opacity:1;"
         offset="0"
         id="stop2502" />
      <stop
         style="stop-color:#fce94f;stop-opacity:0;"
         offset="1"
         id="stop2504" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient2392">
      <stop
         style="stop-color:#eeeeec;stop-opacity:1;"
         offset="0"
         id="stop2394" />
      <stop
         style="stop-color:#eeeeec;stop-opacity:0;"
         offset="1"
         id="stop2396" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       id="linearGradient2254">
      <stop
         style="stop-color:#ffffff;stop-opacity:1;"
         offset="0"
         id="stop2256" />
      <stop
         style="stop-color:#ffffff;stop-opacity:0;"
         offset="1"
         id="stop2258" />
    </linearGradient>
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2263"
       gradientUnits="userSpaceOnUse"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581"
       gradientTransform="translate(-1.608757,3.097272)" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2267"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(3.55502,0.968578)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2271"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(9.263651,3.495228)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2275"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(8.497184,-2.330824)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2279"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(14.4634,2.014073)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2283"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,-0.197462,7.612867)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2287"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.284317,0,0,1,14.61983,4.452335)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2291"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,14.8761,8.569976)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2295"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-5.687359,1.810269)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2299"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,6.38386,6.500432)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2303"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(1.707748,-5.784024)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2311"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-0.976307,0,0,1,53.94753,8.563694)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2350"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(16.14002,24.6642)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2352"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-0.932144,25.8724)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2354"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(5.356636,23.8687)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2356"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(11.19027,26.52035)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2358"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(10.30638,19.27251)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2360"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,0.229156,30.76299)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2362"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.284317,0,0,1,16.67145,27.22746)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2364"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,17.05272,31.4701)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2366"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-4.010744,24.9604)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2368"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,8.185476,29.52556)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2370"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(4.207586,21.30544)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2372"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-0.976307,0,0,1,56.12415,32.08882)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2392"
       id="linearGradient2398"
       x1="6.6651416"
       y1="13.802798"
       x2="41.403877"
       y2="13.802798"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.992367,0,0,0.990713,1.128541,5.404075)" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2426"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(14.4634,2.014073)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2428"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(8.497184,-2.330824)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2430"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-1.608757,3.097272)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2432"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(3.55502,0.968578)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2434"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(9.263651,3.495228)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2436"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,-0.197462,7.612867)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2438"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.284317,0,0,1,14.61983,4.452335)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2440"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,14.8761,8.569976)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2442"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-5.687359,1.810269)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2444"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,6.38386,6.500432)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2446"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-0.976307,0,0,1,53.94753,8.563694)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2392"
       id="linearGradient2448"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.992367,0,0,0.990713,1.128541,5.404075)"
       x1="6.6651416"
       y1="13.802798"
       x2="41.403877"
       y2="13.802798" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2392"
       id="linearGradient2451"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.992367,0,0,0.990713,4.378541,10.65407)"
       x1="6.6651416"
       y1="13.802798"
       x2="41.403877"
       y2="13.802798" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2457"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,9.63386,11.75043)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2460"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-2.437359,7.060269)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2463"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,18.1261,13.81998)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2469"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,3.052538,12.86287)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2472"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(12.51365,8.745228)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2475"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(6.80502,6.218578)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2478"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(1.641243,8.347272)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2483"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(0.842481,-3.998086)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2500"
       id="linearGradient2506"
       x1="37"
       y1="-21.75"
       x2="53.75"
       y2="9"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2500"
       id="linearGradient2509"
       gradientUnits="userSpaceOnUse"
       x1="37"
       y1="-21.75"
       x2="53.75"
       y2="9"
       gradientTransform="matrix(0.889091,0,0,0.617886,-4.771368,39.81402)" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2500"
       id="linearGradient2513"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.605509,0,0,0.710542,-0.224971,42.195)"
       x1="38.857941"
       y1="-18.407482"
       x2="53.75"
       y2="9" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2500"
       id="linearGradient2517"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.414169,0,0,0.778853,-1.910724,36.8785)"
       x1="37"
       y1="-21.75"
       x2="53.75"
       y2="9" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2527"
       id="linearGradient2533"
       x1="-25.137094"
       y1="-1.2491118"
       x2="-35.652866"
       y2="-24.88446"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2537"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(17.33814,3.415985)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2541"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(13.40064,1.353485)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2555"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-7.499805,1.708617)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient2563"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-0.72683,2.481141)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient3347"
       id="linearGradient3353"
       x1="23.303862"
       y1="29.115711"
       x2="29.75"
       y2="46.09293"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3366"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(13.40064,1.353485)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3368"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(1.641243,8.347272)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3370"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(6.80502,6.218578)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3372"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(12.51365,8.745228)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3374"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,3.052538,12.86287)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3376"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,18.1261,13.81998)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3378"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-2.437359,7.060269)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3380"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,9.63386,11.75043)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3383"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,0.795022,6.093572)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3386"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-11.2762,1.403411)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3389"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,9.287262,8.163122)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3392"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,-5.7863,7.206012)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3395"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(3.674812,3.08837)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3398"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-2.033818,0.56172)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3401"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-7.197595,2.690414)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient3405"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(4.561802,-4.303373)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1514"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(88.49344,-9.697877)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1516"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,56.25514,-12.39388)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1518"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.284317,0,0,1,79.36909,-3.193747)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2527"
       id="linearGradient1520"
       gradientUnits="userSpaceOnUse"
       x1="-25.137094"
       y1="-1.2491118"
       x2="-35.652866"
       y2="-24.88446" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1522"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-7.197595,2.690414)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1524"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(-2.033818,0.56172)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1526"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(3.674812,3.08837)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1528"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.751222,0,0,1,-5.7863,7.206012)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1530"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.834148,0,0,1,9.287262,8.163122)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1532"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.462015,0,0,1.262475,-11.2762,1.403411)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1534"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.106619,0,0,1,0.795022,6.093572)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1536"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-0.976307,0,0,1,123.1162,-5.446357)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2254"
       id="linearGradient1538"
       gradientUnits="userSpaceOnUse"
       gradientTransform="translate(57.97693,-10.56876)"
       x1="14.260854"
       y1="9.285902"
       x2="16.851845"
       y2="16.268581" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2527"
       id="linearGradient1557"
       gradientUnits="userSpaceOnUse"
       x1="-25.137094"
       y1="-1.2491118"
       x2="-35.652866"
       y2="-24.88446" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4829"
       id="radialGradient4835"
       cx="-35.001785"
       cy="-1.1439217"
       fx="-35.001785"
       fy="-1.1439217"
       r="17.500893"
       gradientTransform="matrix(1,0,0,0.565657,0,-0.496855)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2298"
       id="linearGradient1427"
       gradientUnits="userSpaceOnUse"
       x1="-27.006643"
       y1="-37.550461"
       x2="-34.700153"
       y2="-4.4493785" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient3478"
       id="linearGradient1431"
       gradientUnits="userSpaceOnUse"
       x1="11.149398"
       y1="-43.997444"
       x2="4.9625983"
       y2="-8.3080902" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient3478"
       id="linearGradient14128"
       gradientUnits="userSpaceOnUse"
       x1="11.149398"
       y1="-43.997444"
       x2="4.9625983"
       y2="-8.3080902" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2527"
       id="linearGradient14130"
       gradientUnits="userSpaceOnUse"
       x1="-25.137094"
       y1="-1.2491118"
       x2="-35.652866"
       y2="-24.88446" />
    <linearGradient
       inkscape:collect="always"
       xlink:href="#linearGradient2298"
       id="linearGradient14132"
       gradientUnits="userSpaceOnUse"
       x1="-27.006643"
       y1="-37.550461"
       x2="-34.700153"
       y2="-4.4493785" />
    <inkscape:perspective
       id="perspective3833"
       inkscape:persp3d-origin="0.5 : 0.33333333 : 1"
       inkscape:vp_z="1 : 0.5 : 1"
       inkscape:vp_y="0 : 1000 : 0"
       inkscape:vp_x="0 : 0.5 : 1"
       sodipodi:type="inkscape:persp3d" />
    <inkscape:perspective
       id="perspective4039"
       inkscape:persp3d-origin="0.5 : 0.33333333 : 1"
       inkscape:vp_z="1 : 0.5 : 1"
       inkscape:vp_y="0 : 1000 : 0"
       inkscape:vp_x="0 : 0.5 : 1"
       sodipodi:type="inkscape:persp3d" />
    <inkscape:perspective
       id="perspective4053"
       inkscape:persp3d-origin="0.5 : 0.33333333 : 1"
       inkscape:vp_z="1 : 0.5 : 1"
       inkscape:vp_y="0 : 1000 : 0"
       inkscape:vp_x="0 : 0.5 : 1"
       sodipodi:type="inkscape:persp3d" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4215"
       id="radialGradient4221"
       cx="-27.421984"
       cy="-16.482727"
       fx="-27.421984"
       fy="-16.482727"
       r="9.7810764"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-1.4320604,-0.44666345,0.29775312,-0.95464282,-61.784137,-44.466242)" />
    <radialGradient
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       r="19.094028"
       fy="31.09733"
       fx="37.17944"
       cy="31.09733"
       cx="37.17944"
       id="radialGradient6533"
       xlink:href="#linearGradient6527"
       inkscape:collect="always" />
    <linearGradient
       y2="21.336346"
       x2="-21.962101"
       y1="15.649428"
       x1="-21.658581"
       gradientUnits="userSpaceOnUse"
       id="linearGradient6019"
       xlink:href="#linearGradient6001"
       inkscape:collect="always" />
    <linearGradient
       y2="22.661524"
       x2="-22.113543"
       y1="28.337734"
       x1="-22.822565"
       gradientUnits="userSpaceOnUse"
       id="linearGradient6015"
       xlink:href="#linearGradient6001"
       inkscape:collect="always" />
    <linearGradient
       y2="22.661524"
       x2="-22.113543"
       y1="30.057165"
       x1="-25.176178"
       gradientUnits="userSpaceOnUse"
       id="linearGradient6011"
       xlink:href="#linearGradient6001"
       inkscape:collect="always" />
    <linearGradient
       gradientUnits="userSpaceOnUse"
       y2="21.041553"
       x2="-22.252472"
       y1="30.057165"
       x1="-25.176178"
       id="linearGradient6007"
       xlink:href="#linearGradient6001"
       inkscape:collect="always" />
    <radialGradient
       r="6.7175145"
       fy="12.493138"
       fx="12.071323"
       cy="12.493138"
       cx="12.071323"
       gradientUnits="userSpaceOnUse"
       id="radialGradient5989"
       xlink:href="#linearGradient4825"
       inkscape:collect="always" />
    <radialGradient
       r="6.7175145"
       fy="12.493138"
       fx="12.071323"
       cy="12.493138"
       cx="12.071323"
       gradientUnits="userSpaceOnUse"
       id="radialGradient5987"
       xlink:href="#linearGradient4825"
       inkscape:collect="always" />
    <radialGradient
       r="6.7175145"
       fy="12.493138"
       fx="12.071323"
       cy="12.493138"
       cx="12.071323"
       gradientUnits="userSpaceOnUse"
       id="radialGradient5985"
       xlink:href="#linearGradient4825"
       inkscape:collect="always" />
    <radialGradient
       r="6.7175145"
       fy="12.493138"
       fx="12.071323"
       cy="12.493138"
       cx="12.071323"
       gradientUnits="userSpaceOnUse"
       id="radialGradient5983"
       xlink:href="#linearGradient4825"
       inkscape:collect="always" />
    <linearGradient
       id="linearGradient3962">
      <stop
         id="stop3964"
         offset="0.0000000"
         style="stop-color:#d3e9ff;stop-opacity:1.0000000;" />
      <stop
         id="stop4134"
         offset="0.15517241"
         style="stop-color:#d3e9ff;stop-opacity:1.0000000;" />
      <stop
         id="stop4346"
         offset="0.75000000"
         style="stop-color:#4074ae;stop-opacity:1.0000000;" />
      <stop
         id="stop3966"
         offset="1.0000000"
         style="stop-color:#36486c;stop-opacity:1.0000000;" />
    </linearGradient>
    <linearGradient
       id="linearGradient4126">
      <stop
         id="stop4128"
         offset="0.0000000"
         style="stop-color:#ffffff;stop-opacity:1.0000000;" />
      <stop
         id="stop4130"
         offset="1.0000000"
         style="stop-color:#ffffff;stop-opacity:0.16494845;" />
    </linearGradient>
    <linearGradient
       id="linearGradient4825"
       inkscape:collect="always">
      <stop
         id="stop4827"
         offset="0"
         style="stop-color:#ffffff;stop-opacity:1;" />
      <stop
         id="stop4829"
         offset="1"
         style="stop-color:#ffffff;stop-opacity:0;" />
    </linearGradient>
    <linearGradient
       id="linearGradient6001"
       inkscape:collect="always">
      <stop
         id="stop6003"
         offset="0"
         style="stop-color:#ffffff;stop-opacity:1;" />
      <stop
         id="stop6005"
         offset="1"
         style="stop-color:#ffffff;stop-opacity:0;" />
    </linearGradient>
    <linearGradient
       id="linearGradient6527">
      <stop
         id="stop6529"
         offset="0"
         style="stop-color:#346604;stop-opacity:1;" />
      <stop
         id="stop6531"
         offset="1"
         style="stop-color:#4e9a06;stop-opacity:1;" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5137"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5139"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5143"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5145"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5149"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5151"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5155"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5157"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5161"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5163"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5167"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5169"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5173"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5175"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5179"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5181"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5185"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5189"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5191"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5195"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5199"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5201"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5205"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5207"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5211"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6527"
       id="radialGradient5213"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(0.95295618,-0.02665615,0.02617771,0.93591558,0.66318174,2.1792646)"
       cx="37.17944"
       cy="31.09733"
       fx="37.17944"
       fy="31.09733"
       r="19.094028" />
    <radialGradient
       gradientUnits="userSpaceOnUse"
       r="12.289036"
       fy="63.965389"
       fx="15.115514"
       cy="63.965389"
       cx="15.115514"
       gradientTransform="scale(1.64399,0.608276)"
       id="radialGradient4120-9"
       xlink:href="#linearGradient4114-4"
       inkscape:collect="always" />
    <linearGradient
       id="linearGradient4114-4"
       inkscape:collect="always">
      <stop
         id="stop4116-1"
         offset="0"
         style="stop-color:#000000;stop-opacity:1;" />
      <stop
         id="stop4118-5"
         offset="1"
         style="stop-color:#000000;stop-opacity:0;" />
    </linearGradient>
    <radialGradient
       r="12.289036"
       fy="63.965389"
       fx="15.115514"
       cy="63.965389"
       cx="15.115514"
       gradientTransform="scale(1.64399,0.608276)"
       gradientUnits="userSpaceOnUse"
       id="radialGradient5234"
       xlink:href="#linearGradient4114-4"
       inkscape:collect="always" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4126-0"
       id="radialGradient3976"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1,0,0,0.5,0,20)"
       cx="23.857143"
       cy="40"
       fx="23.857143"
       fy="40"
       r="17.142857" />
    <linearGradient
       id="linearGradient4126-0"
       inkscape:collect="always">
      <stop
         id="stop4128-2"
         offset="0"
         style="stop-color:#000000;stop-opacity:1;" />
      <stop
         id="stop4130-5"
         offset="1"
         style="stop-color:#000000;stop-opacity:0;" />
    </linearGradient>
    <radialGradient
       r="17.142857"
       fy="40"
       fx="23.857143"
       cy="40"
       cx="23.857143"
       gradientTransform="matrix(1,0,0,0.5,0,20)"
       gradientUnits="userSpaceOnUse"
       id="radialGradient6040"
       xlink:href="#linearGradient4126-0"
       inkscape:collect="always" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4215-9"
       id="radialGradient4221-0"
       cx="-27.421984"
       cy="-16.482727"
       fx="-27.421984"
       fy="-16.482727"
       r="9.7810764"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(-1.4320604,-0.44666345,0.29775312,-0.95464282,-61.784137,-44.466242)" />
    <linearGradient
       id="linearGradient4215-9">
      <stop
         style="stop-color:#61330d;stop-opacity:0;"
         offset="0"
         id="stop4217-7" />
      <stop
         style="stop-color:#7b4111;stop-opacity:0.60176992;"
         offset="1"
         id="stop4219-7" />
    </linearGradient>
    <filter
       id="filter4154"
       inkscape:label="Noisy blur"
       inkscape:menu="Blurs"
       inkscape:menu-tooltip="Small-scale roughening and blurring to edges and content"
       x="-0.25"
       width="1.5"
       y="-0.25"
       height="1.5"
       color-interpolation-filters="sRGB">
      <feGaussianBlur
         id="feGaussianBlur4156"
         stdDeviation="5"
         result="result1" />
      <feTurbulence
         id="feTurbulence4158"
         numOctaves="1"
         seed="0"
         type="fractalNoise"
         baseFrequency="0.1"
         result="result2" />
      <feDisplacementMap
         id="feDisplacementMap4160"
         in2="result2"
         scale="5"
         yChannelSelector="G"
         xChannelSelector="R"
         result="result3"
         in="result1" />
      <feComposite
         id="feComposite4162"
         in2="result3"
         operator="atop" />
    </filter>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6138"
       id="radialGradient6144"
       cx="-23.089966"
       cy="2.5901756"
       fx="-23.089966"
       fy="2.5901756"
       r="9.0739966"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6146"
       id="radialGradient6152"
       cx="-11.868641"
       cy="1.9472617"
       fx="-11.868641"
       fy="1.9472617"
       r="9.0739966"
       gradientTransform="matrix(1.3361511,-1.0747951,0.74381645,0.92468904,-1.4467243,1.3984522)"
       gradientUnits="userSpaceOnUse" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6154"
       id="radialGradient6160"
       cx="-20"
       cy="6.5"
       fx="-20"
       fy="6.5"
       r="9.0739966"
       gradientTransform="matrix(1,0,0,1.0551025,0,-0.35816632)"
       gradientUnits="userSpaceOnUse" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6146"
       id="radialGradient6167"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.3361511,-1.0747951,0.74381645,0.92468904,-1.4467243,1.3984522)"
       cx="-11.868641"
       cy="1.9472617"
       fx="-11.868641"
       fy="1.9472617"
       r="9.0739966" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6154-9"
       id="radialGradient6160-8"
       cx="-20"
       cy="6.5"
       fx="-20"
       fy="6.5"
       r="9.0739965"
       gradientTransform="matrix(1,0,0,1.0551025,0,-0.35816632)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6154-9">
      <stop
         style="stop-color:#ffe6d5;stop-opacity:1;"
         offset="0"
         id="stop6156-8" />
      <stop
         style="stop-color:#ffe6d5;stop-opacity:0;"
         offset="1"
         id="stop6158-7" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6146-6"
       id="radialGradient6167-1"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.3361511,-1.0747951,0.74381645,0.92468904,-1.4467243,1.3984522)"
       cx="-11.868641"
       cy="1.9472617"
       fx="-11.868641"
       fy="1.9472617"
       r="9.0739965" />
    <linearGradient
       id="linearGradient6146-6">
      <stop
         style="stop-color:#000000;stop-opacity:1"
         offset="0"
         id="stop6148-7" />
      <stop
         style="stop-color:#61320d;stop-opacity:0;"
         offset="1"
         id="stop6150-0" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6138-4"
       id="radialGradient6144-3"
       cx="-23.089966"
       cy="2.5901756"
       fx="-23.089966"
       fy="2.5901756"
       r="9.0739965"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6138-4">
      <stop
         style="stop-color:#ffb380;stop-opacity:1"
         offset="0"
         id="stop6140-1" />
      <stop
         style="stop-color:#803300;stop-opacity:1"
         offset="1"
         id="stop6142-1" />
    </linearGradient>
    <radialGradient
       r="9.0739965"
       fy="2.5901756"
       fx="-23.089966"
       cy="2.5901756"
       cx="-23.089966"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse"
       id="radialGradient6239"
       xlink:href="#linearGradient6138-4"
       inkscape:collect="always" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6154-2"
       id="radialGradient6160-0"
       cx="-20"
       cy="6.5"
       fx="-20"
       fy="6.5"
       r="9.0739965"
       gradientTransform="matrix(1,0,0,1.0551025,0,-0.35816632)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6154-2">
      <stop
         style="stop-color:#ffe6d5;stop-opacity:1;"
         offset="0"
         id="stop6156-1" />
      <stop
         style="stop-color:#ffe6d5;stop-opacity:0;"
         offset="1"
         id="stop6158-74" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6146-2"
       id="radialGradient6167-9"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.3361511,-1.0747951,0.74381645,0.92468904,-1.4467243,1.3984522)"
       cx="-11.868641"
       cy="1.9472617"
       fx="-11.868641"
       fy="1.9472617"
       r="9.0739965" />
    <linearGradient
       id="linearGradient6146-2">
      <stop
         style="stop-color:#000000;stop-opacity:1"
         offset="0"
         id="stop6148-6" />
      <stop
         style="stop-color:#61320d;stop-opacity:0;"
         offset="1"
         id="stop6150-03" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6138-49"
       id="radialGradient6144-8"
       cx="-23.089966"
       cy="2.5901756"
       fx="-23.089966"
       fy="2.5901756"
       r="9.0739965"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6138-49">
      <stop
         style="stop-color:#ffb380;stop-opacity:1"
         offset="0"
         id="stop6140-4" />
      <stop
         style="stop-color:#803300;stop-opacity:1"
         offset="1"
         id="stop6142-4" />
    </linearGradient>
    <radialGradient
       r="9.0739965"
       fy="2.5901756"
       fx="-23.089966"
       cy="2.5901756"
       cx="-23.089966"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse"
       id="radialGradient6239-1"
       xlink:href="#linearGradient6138-49"
       inkscape:collect="always" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6154-3"
       id="radialGradient6160-4"
       cx="-20"
       cy="6.5"
       fx="-20"
       fy="6.5"
       r="9.0739965"
       gradientTransform="matrix(1,0,0,1.0551025,0,-0.35816632)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6154-3">
      <stop
         style="stop-color:#ffe6d5;stop-opacity:1;"
         offset="0"
         id="stop6156-7" />
      <stop
         style="stop-color:#ffe6d5;stop-opacity:0;"
         offset="1"
         id="stop6158-5" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6146-26"
       id="radialGradient6167-5"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1.3361511,-1.0747951,0.74381645,0.92468904,-1.4467243,1.3984522)"
       cx="-11.868641"
       cy="1.9472617"
       fx="-11.868641"
       fy="1.9472617"
       r="9.0739965" />
    <linearGradient
       id="linearGradient6146-26">
      <stop
         style="stop-color:#000000;stop-opacity:1"
         offset="0"
         id="stop6148-73" />
      <stop
         style="stop-color:#61320d;stop-opacity:0;"
         offset="1"
         id="stop6150-07" />
    </linearGradient>
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient6138-3"
       id="radialGradient6144-5"
       cx="-23.089966"
       cy="2.5901756"
       fx="-23.089966"
       fy="2.5901756"
       r="9.0739965"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse" />
    <linearGradient
       inkscape:collect="always"
       id="linearGradient6138-3">
      <stop
         style="stop-color:#ffb380;stop-opacity:1"
         offset="0"
         id="stop6140-6" />
      <stop
         style="stop-color:#803300;stop-opacity:1"
         offset="1"
         id="stop6142-9" />
    </linearGradient>
    <radialGradient
       r="9.0739965"
       fy="2.5901756"
       fx="-23.089966"
       cy="2.5901756"
       cx="-23.089966"
       gradientTransform="matrix(1.32772,0.14198075,-0.17977965,1.6811928,7.7229676,-1.5881385)"
       gradientUnits="userSpaceOnUse"
       id="radialGradient6239-4"
       xlink:href="#linearGradient6138-3"
       inkscape:collect="always" />
    <radialGradient
       inkscape:collect="always"
       xlink:href="#linearGradient4126-0"
       id="radialGradient8952"
       gradientUnits="userSpaceOnUse"
       gradientTransform="matrix(1,0,0,0.5,0,20)"
       cx="23.857143"
       cy="40"
       fx="23.857143"
       fy="40"
       r="17.142857" />
  </defs>
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.5"
     inkscape:cx="837.59462"
     inkscape:cy="453.69303"
     inkscape:current-layer="layer3"
     showgrid="true"
     inkscape:grid-bbox="true"
     inkscape:document-units="px"
     inkscape:window-width="1680"
     inkscape:window-height="975"
     inkscape:window-x="0"
     inkscape:window-y="25"
     inkscape:showpageshadow="false"
     inkscape:object-nodes="false"
     inkscape:window-maximized="1"
     inkscape:snap-bbox="true"
     inkscape:snap-global="false">
    <inkscape:grid
       type="xygrid"
       id="grid4061"
       empspacing="5"
       visible="true"
       enabled="true"
       snapvisiblegridlinesonly="true"
       spacingx="1px"
       spacingy="1px" />
  </sodipodi:namedview>
  <metadata
     id="metadata1311">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title />
        <dc:date>January 2006</dc:date>
        <dc:creator>
          <cc:Agent>
            <dc:title>Ryan Collier (pseudo)</dc:title>
          </cc:Agent>
        </dc:creator>
        <dc:publisher>
          <cc:Agent>
            <dc:title>http://www.tango-project.org</dc:title>
          </cc:Agent>
        </dc:publisher>
        <dc:source>http://www.pseudocode.org</dc:source>
        <dc:subject>
          <rdf:Bag>
            <rdf:li>weather</rdf:li>
            <rdf:li>applet</rdf:li>
            <rdf:li>notification</rdf:li>
          </rdf:Bag>
        </dc:subject>
        <cc:license
           rdf:resource="http://creativecommons.org/licenses/by-sa/2.0/" />
      </cc:Work>
      <cc:License
         rdf:about="http://creativecommons.org/licenses/by-sa/2.0/">
        <cc:permits
           rdf:resource="http://web.resource.org/cc/Reproduction" />
        <cc:permits
           rdf:resource="http://web.resource.org/cc/Distribution" />
        <cc:requires
           rdf:resource="http://web.resource.org/cc/Notice" />
        <cc:requires
           rdf:resource="http://web.resource.org/cc/Attribution" />
        <cc:permits
           rdf:resource="http://web.resource.org/cc/DerivativeWorks" />
        <cc:requires
           rdf:resource="http://web.resource.org/cc/ShareAlike" />
      </cc:License>
    </rdf:RDF>
  </metadata>
  <g
     id="layer1"
     inkscape:label="Layer 1"
     inkscape:groupmode="layer"
     transform="translate(0,1032)">
    <g
       id="g8929"
       transform="matrix(0.99798237,0.0634916,-0.0634916,0.99798237,-26.129345,-61.138839)">
      <path
         sodipodi:type="arc"
         style="opacity:0.6;color:#000000;fill:url(#radialGradient8952);fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:1;marker:none;visibility:visible;display:block;overflow:visible"
         id="path6548"
         sodipodi:cx="23.857143"
         sodipodi:cy="40"
         sodipodi:rx="17.142857"
         sodipodi:ry="8.5714283"
         d="m 41,40 c 0,4.733869 -7.675118,8.571428 -17.142857,8.571428 -9.467738,0 -17.1428562,-3.837559 -17.1428562,-8.571428 0,-4.733869 7.6751182,-8.571428 17.1428562,-8.571428 C 33.324882,31.428572 41,35.266131 41,40 z"
         transform="matrix(15.546112,0,0,7.6238107,168.93201,-483.15022)"
         inkscape:r_cx="true"
         inkscape:r_cy="true" />
      <path
         transform="matrix(29.043089,0,0,29.043089,2173.4915,-468.62866)"
         d="M -46.5,0.24999997 C -46.5,5.6347763 -50.865224,10 -56.25,10 -61.634776,10 -66,5.6347763 -66,0.24999997 -66,-5.1347763 -61.634776,-9.5 -56.25,-9.5 c 5.384776,0 9.75,4.3652237 9.75,9.74999997 z"
         sodipodi:ry="9.75"
         sodipodi:rx="9.75"
         sodipodi:cy="0.24999997"
         sodipodi:cx="-56.25"
         id="path7596"
         style="fill:#aa592d;fill-opacity:1;stroke:none"
         sodipodi:type="arc" />
      <a
         id="a8884">
        <path
           id="path4203"
           d="m 347.02404,-645.69621 96.97252,-63.42656 50.25284,-14.51928 108.09346,2.06875 2.92733,6.1912 -263.78119,84.57507 5.53498,-14.88917 z"
           style="fill:#b69564;fill-opacity:1;stroke:none"
           inkscape:connector-curvature="0" />
      </a>
      <path
         sodipodi:nodetypes="cssssssssssc"
         id="path4117"
         d="m 274.81343,-420.81724 c 6.9985,-31.70839 83.07967,-63.01904 115.01334,-60.67118 26.91146,1.9786 56.239,-14.3438 90.65733,-36.30536 21.56391,-13.75944 56.03679,6.57703 118.05789,-37.15142 30.14934,-21.25701 58.93453,-32.14508 101.65013,-42.91253 19.96461,-5.03254 43.7209,-12.55821 56.55248,-9.53456 15.26143,3.59624 18.21177,19.07118 24.76136,28.97465 29.93558,45.26477 -30.46746,82.08386 -91.92511,82.07684 -52.58518,-0.006 -73.86201,58.19626 -133.87042,67.33804 -65.55345,9.98651 -139.27637,30.99326 -154.76887,50.08955 -16.26657,20.05042 -65.72632,36.56632 -85.29746,21.86388 -18.19992,-13.67235 -30.96012,-39.34882 -40.83067,-63.76791 z"
         style="fill:#b76c3c;fill-opacity:1;stroke:none"
         inkscape:connector-curvature="0" />
      <path
         id="path4069"
         d="m 337.95292,-300.64771 461.39775,-142.61656 1.00876,-45.91018 -485.58639,150.0932 z"
         style="fill:#d3bda1;fill-opacity:1;stroke:none"
         sodipodi:nodetypes="ccccc"
         inkscape:connector-curvature="0" />
      <path
         style="fill:#d3bda1;fill-opacity:1;stroke:none"
         d="m 605.29068,-405.54152 c 30.62694,30.44326 133.65292,62.62882 179.47364,-55.26926 -27.17917,-1.00321 -183.10555,54.38533 -179.47364,55.26926 z"
         id="path4077"
         sodipodi:nodetypes="ccc"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="ccc"
         id="path4071"
         d="m 602.78606,-413.64453 c 8.10649,-42.41564 75.0012,-127.12315 179.3577,-55.64436 -21.87255,16.16493 -181.85735,58.42353 -179.3577,55.64436 z"
         style="fill:#d3bda1;fill-opacity:1;stroke:none"
         inkscape:connector-curvature="0" />
      <path
         id="path7610"
         d="m 399.44643,-436.64041 c -0.22097,-0.11662 0.49886,-0.1542 0,0 z"
         style="fill:none;stroke:#000000;stroke-width:14.52157402px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="cc"
         id="path4059"
         d="M 304.51895,-603.06341 651.36643,-710.27285"
         style="fill:#000000;fill-opacity:0;stroke:#a09b8c;stroke-width:14.52154446;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="cc"
         style="fill:#cfa565;fill-opacity:1;stroke:#cfa565;stroke-width:14.52154446;stroke-opacity:1"
         d="M 298.93354,-574.90134 673.5285,-690.68744"
         id="path4063"
         inkscape:connector-curvature="0" />
      <path
         transform="matrix(15.672367,-4.8442783,5.6511693,18.282847,20.959728,-857.54495)"
         d="M 35,31.375 C 35,32.272463 33.488961,33 31.625,33 29.761039,33 28.25,32.272463 28.25,31.375 c 0,-0.897463 1.511039,-1.625 3.375,-1.625 1.863961,0 3.375,0.727537 3.375,1.625 z"
         sodipodi:ry="1.625"
         sodipodi:rx="3.375"
         sodipodi:cy="31.375"
         sodipodi:cx="31.625"
         id="path4065"
         style="fill:#fbad3e;fill-opacity:1;stroke:#ca6919;stroke-width:0.81961387;stroke-linecap:round;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
         sodipodi:type="arc" />
      <path
         sodipodi:type="arc"
         style="fill:#f57900;fill-opacity:1;stroke:none"
         id="path4067"
         sodipodi:cx="31.625"
         sodipodi:cy="31.375"
         sodipodi:rx="3.375"
         sodipodi:ry="1.625"
         d="M 35,31.375 C 35,32.272463 33.488961,33 31.625,33 29.761039,33 28.25,32.272463 28.25,31.375 c 0,-0.897463 1.511039,-1.625 3.375,-1.625 1.863961,0 3.375,0.727537 3.375,1.625 z"
         transform="matrix(6.6800466,-2.064781,2.3962843,7.752537,407.46405,-615.05796)" />
      <path
         style="fill:#000000;fill-opacity:0;stroke:#7d6f62;stroke-width:14.52154446;stroke-opacity:1"
         d="m 417.3685,-218.32459 353.78435,-109.3536"
         id="path4079"
         sodipodi:nodetypes="cc"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="cc"
         id="path4081"
         d="M 406.14268,-230.05418 780.73839,-345.84051"
         style="fill:#d3bda1;fill-opacity:1;stroke:#d3bda1;stroke-width:14.52154446;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="ccccc"
         id="path4085"
         d="m 277.25918,-425.80775 5.92504,43.75545 513.31569,-158.66424 -19.79878,-39.46712 z"
         style="font-size:medium;font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;text-indent:0;text-align:start;text-decoration:none;line-height:normal;letter-spacing:normal;word-spacing:normal;text-transform:none;direction:ltr;block-progression:tb;writing-mode:lr-tb;text-anchor:start;color:#000000;fill:#e8cb9e;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:2.21930504;marker:none;visibility:visible;display:inline;overflow:visible;enable-background:accumulate;font-family:Bitstream Vera Sans;-inkscape-font-specification:Bitstream Vera Sans"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="cc"
         id="path4087"
         d="m 286.69921,-542.72125 416.21656,-128.6512"
         style="fill:#cfa565;fill-opacity:1;stroke:#dcb999;stroke-width:14.52154446;stroke-opacity:1"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="ccccc"
         id="path4091"
         d="m 272.0923,-515.49577 -5.35951,31.83383 486.06838,-150.24218 -22.38815,-23.25711 z"
         style="font-size:medium;font-style:normal;font-variant:normal;font-weight:normal;font-stretch:normal;text-indent:0;text-align:start;text-decoration:none;line-height:normal;letter-spacing:normal;word-spacing:normal;text-transform:none;direction:ltr;block-progression:tb;writing-mode:lr-tb;text-anchor:start;color:#000000;fill:#d6aa67;fill-opacity:1;fill-rule:nonzero;stroke:none;stroke-width:1.47953665;marker:none;visibility:visible;display:inline;overflow:visible;enable-background:accumulate;font-family:Bitstream Vera Sans;-inkscape-font-specification:Bitstream Vera Sans"
         inkscape:connector-curvature="0" />
      <path
         sodipodi:nodetypes="cc"
         id="path4093"
         d="M 276.10448,-478.64945 754.75382,-626.59842"
         style="fill:#eeeeec;fill-opacity:1;stroke:#babdb6;stroke-width:14.12199974;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none"
         inkscape:connector-curvature="0" />
      <path
         inkscape:connector-curvature="0"
         sodipodi:nodetypes="cc"
         id="path5215"
         d="m 483.58541,-200.7939 249.73017,-77.19079"
         style="fill:#956232;fill-opacity:1;stroke:#956232;stroke-width:14.52154446;stroke-opacity:1" />
      <path
         style="fill:#ae8c6a;fill-opacity:1;stroke:#ae8c6a;stroke-width:29.04308701;stroke-opacity:1"
         d="m 510.82871,-186.41584 208.10856,-64.32568"
         id="path5217"
         sodipodi:nodetypes="cc"
         inkscape:connector-curvature="0" />
    </g>
    <path
       style="fill:none;stroke:#61330d;stroke-width:14.52154446;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
       d="m 810.37727,-570.99471 c 34.3603,105.92753 -2.30484,229.66114 -88.18242,300.35394 -84.45919,72.72708 -212.9527,87.47355 -311.51566,35.26908 -98.8235,-49.02863 -161.70205,-159.99207 -153.52165,-269.92782 5.85887,-112.12204 85.10683,-215.9219 192.09989,-250.36616 105.15064,-37.12913 229.95161,-3.53442 302.80707,80.72043 26.56786,29.96279 46.53314,65.6862 58.31277,103.95053 z"
       id="path7661"
       inkscape:connector-curvature="0" />
    <path
       style="fill:none;stroke:#a35415;stroke-width:5.34899998;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:21.396, 21.396;stroke-dashoffset:0"
       d="m 889.56757,-487.45791 c 1.90824,193.61965 -86.41573,380.34893 -213.43353,453.691864 C 550.04719,43.684741 393.17211,2.201684 295.9864,-135.13665 197.3362,-267.33278 163.63868,-483.9626 213.34903,-662.39657 c 47.76994,-183.2581 179.03664,-315.00555 317.74027,-317.28658 137.50982,-7.68743 272.4137,112.20796 327.60827,289.59035 20.40522,63.41921 30.92629,133.01807 30.87,202.63489 z"
       id="path7661-0"
       inkscape:connector-curvature="0" />
    <path
       inkscape:connector-curvature="0"
       id="path4322"
       d="M 740.32206,-777.64659 C 898.31819,-668.45183 999.1045,-488.30232 985.867,-340.90862 976.49103,-191.93736 853.11879,-85.457893 686.21901,-83.366689 522.64842,-77.117764 327.81735,-173.09108 211.6607,-316.44329 90.48448,-460.94498 58.82348,-645.28139 136.33371,-761.7171 c 72.44599,-118.53807 246.79077,-161.91708 422.11617,-106.24262 63.06806,19.34773 125.48874,50.43544 181.87218,90.31313 z"
       style="fill:none;stroke:#a35415;stroke-width:5.34899998;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:21.396, 21.396;stroke-dashoffset:0" />
    <path
       inkscape:connector-curvature="0"
       id="path4324"
       d="m 540.21403,-841.24495 c 191.31131,-1.93125 375.81439,87.45841 448.28287,216.00883 76.5274,127.60821 35.5389,286.37615 -100.16201,384.73448 C 757.7148,-140.66112 543.66768,-106.557 367.36103,-156.86716 186.28776,-205.21348 56.111013,-338.06406 53.857198,-478.44128 46.261414,-617.61029 164.72739,-754.14191 339.99501,-810.00246 c 62.66312,-20.65144 131.4322,-31.29944 200.21902,-31.24249 z"
       style="fill:none;stroke:#a35415;stroke-width:5.34899998;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:21.396, 21.396;stroke-dashoffset:0" />
    <path
       inkscape:connector-curvature="0"
       id="path4326"
       d="m 293.076,-737.73222 c 133.92817,-138.27538 326.84603,-207.10488 467.90418,-168.0673 143.26991,35.46665 225.21412,177.0655 197.97967,343.7282 -22.6061,164.0747 -150.13253,341.37036 -309.95067,431.96756 C 487.19261,-34.706723 302.32414,-35.486732 202.6522,-133.1355 100.04703,-226.10702 88.42368,-407.42831 173.32815,-572.35597 203.209,-631.80288 244.39655,-688.54598 293.076,-737.73222 z"
       style="fill:none;stroke:#a35415;stroke-width:5.34899998;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:21.396, 21.396;stroke-dashoffset:0" />
  </g>
  <g
     inkscape:groupmode="layer"
     id="layer3"
     inkscape:label="Shade"
     transform="translate(0,1032)">
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient4221);fill-opacity:1;stroke:#d3d7cf;stroke-width:0.5136767;stroke-linecap:square;stroke-linejoin:miter;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none"
       id="path7663"
       sodipodi:cx="-32"
       sodipodi:cy="-17.5"
       sodipodi:rx="9.5"
       sodipodi:ry="9.5"
       d="m -22.5,-17.5 a 9.5,9.5 0 1 1 -19,0 9.5,9.5 0 1 1 19,0 z"
       transform="matrix(-26.144125,-10.7548,10.754835,-26.144158,-108.76732,-1289.0757)" />
    <path
       sodipodi:type="arc"
       style="fill:#ffffff;fill-opacity:1;stroke:#61320d;stroke-width:0.37561747;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
       id="path4334"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(6.6557073,0,0,6.6557073,788.33398,-671.64442)" />
    <path
       sodipodi:type="arc"
       style="fill:#ffffff;fill-opacity:1;stroke:#61320d;stroke-width:0.90931326;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
       id="path4334-0"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(2.7493276,0,0,2.7493276,569.99932,-522.41586)" />
    <path
       sodipodi:type="arc"
       style="fill:#ffffff;fill-opacity:1;stroke:#61320d;stroke-width:1.52410042;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
       id="path4334-0-4"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(1.6462014,0,0,1.6344434,509.2797,-482.08961)" />
    <path
       sodipodi:type="arc"
       style="fill:#ffffff;fill-opacity:1;stroke:#61320d;stroke-width:0.57302231;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0"
       id="path4334-5"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(4.362832,0,0,4.362832,656.80413,-585.14056)" />
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6144);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(6.6557073,0,0,6.6557073,1012.1925,-882.36249)"
       inkscape:transform-center-x="-19.79899"
       inkscape:transform-center-y="23.688077" />
    <text
       xml:space="preserve"
       style="font-size:144px;font-style:normal;font-variant:normal;font-weight:bold;font-stretch:normal;text-align:start;line-height:125%;letter-spacing:0px;word-spacing:0px;writing-mode:lr-tb;text-anchor:start;fill:#ffffff;fill-opacity:1;stroke:#61320d;stroke-width:2.5;stroke-miterlimit:4;stroke-opacity:1;stroke-dasharray:none;stroke-dashoffset:0;font-family:Sans;-inkscape-font-specification:Sans Bold"
       x="347.89655"
       y="-317.55341"
       id="text3222"
       sodipodi:linespacing="125%"><tspan
         sodipodi:role="line"
         id="tspan3224"
         x="347.89655"
         y="-317.55341">Leda</tspan></text>
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6167);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-8"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(6.6557073,0,0,6.6557073,1012.8334,-881.93238)"
       inkscape:transform-center-x="-19.79899"
       inkscape:transform-center-y="23.688077" />
    <a
       id="a6170"
       style="opacity:0.53035147"
       transform="translate(0,-26)">
      <path
         inkscape:transform-center-y="5.4726862"
         inkscape:transform-center-x="-4.57419"
         transform="matrix(1.5376775,0,0,1.5376775,884.53912,-862.04996)"
         d="m -11,6.5 c 0,5.246705 -4.029437,9.5 -9,9.5 -4.970563,0 -9,-4.253295 -9,-9.5 0,-5.2467051 4.029437,-9.5 9,-9.5 4.970563,0 9,4.2532949 9,9.5 z"
         sodipodi:ry="9.5"
         sodipodi:rx="9"
         sodipodi:cy="6.5"
         sodipodi:cx="-20"
         id="path4334-55-8-8"
         style="opacity:0.64536737;fill:url(#radialGradient6160);fill-opacity:1;fill-rule:nonzero;stroke:none"
         sodipodi:type="arc" />
    </a>
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6239);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-5"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(2.9315315,0,0,2.9315315,982.7926,-202.64968)"
       inkscape:transform-center-x="-8.7205381"
       inkscape:transform-center-y="10.4335" />
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6167-1);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-8-9"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(2.9315315,0,0,2.9315315,983.0749,-202.46024)"
       inkscape:transform-center-x="-8.7205513"
       inkscape:transform-center-y="10.433501" />
    <a
       transform="matrix(0.4404538,0,0,0.4404538,536.96857,174.53844)"
       id="a6170-0"
       style="opacity:0.53035147">
      <path
         inkscape:transform-center-y="5.4726862"
         inkscape:transform-center-x="-4.57419"
         transform="matrix(1.5376775,0,0,1.5376775,884.53912,-862.04996)"
         d="m -11,6.5 c 0,5.246705 -4.029437,9.5 -9,9.5 -4.970563,0 -9,-4.253295 -9,-9.5 0,-5.2467051 4.029437,-9.5 9,-9.5 4.970563,0 9,4.2532949 9,9.5 z"
         sodipodi:ry="9.5"
         sodipodi:rx="9"
         sodipodi:cy="6.5"
         sodipodi:cx="-20"
         id="path4334-55-8-8-8"
         style="opacity:0.64536737;fill:url(#radialGradient6160-8);fill-opacity:1;fill-rule:nonzero;stroke:none"
         sodipodi:type="arc" />
    </a>
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6239-1);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-2"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(4.4675255,0,0,4.4675255,145.70395,-525.84731)"
       inkscape:transform-center-x="-13.289721"
       inkscape:transform-center-y="15.9002" />
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6167-9);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-8-4"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(4.4675255,0,0,4.4675255,146.13415,-525.55861)"
       inkscape:transform-center-x="-13.289721"
       inkscape:transform-center-y="15.900203" />
    <a
       transform="matrix(0.67123227,0,0,0.67123227,-533.71232,48.970843)"
       id="a6170-2"
       style="opacity:0.53035147">
      <path
         inkscape:transform-center-y="5.4726862"
         inkscape:transform-center-x="-4.57419"
         transform="matrix(1.5376775,0,0,1.5376775,884.53912,-862.04996)"
         d="m -11,6.5 c 0,5.246705 -4.029437,9.5 -9,9.5 -4.970563,0 -9,-4.253295 -9,-9.5 0,-5.2467051 4.029437,-9.5 9,-9.5 4.970563,0 9,4.2532949 9,9.5 z"
         sodipodi:ry="9.5"
         sodipodi:rx="9"
         sodipodi:cy="6.5"
         sodipodi:cx="-20"
         id="path4334-55-8-8-0"
         style="opacity:0.64536737;fill:url(#radialGradient6160-0);fill-opacity:1;fill-rule:nonzero;stroke:none"
         sodipodi:type="arc" />
    </a>
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6239-4);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-87"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(1.6671025,0,0,1.6671025,557.30348,-989.17925)"
       inkscape:transform-center-x="-4.959184"
       inkscape:transform-center-y="5.9333145" />
    <path
       sodipodi:type="arc"
       style="fill:url(#radialGradient6167-5);fill-opacity:1;fill-rule:nonzero;stroke:none"
       id="path4334-55-8-6"
       sodipodi:cx="-20"
       sodipodi:cy="6.5"
       sodipodi:rx="9"
       sodipodi:ry="9.5"
       d="m -11,6.5 a 9,9.5 0 1 1 -18,0 9,9.5 0 1 1 18,0 z"
       transform="matrix(1.6671025,0,0,1.6671025,557.46402,-989.07151)"
       inkscape:transform-center-x="-4.9591932"
       inkscape:transform-center-y="5.9333243" />
    <a
       transform="matrix(0.25047713,0,0,0.25047713,303.77242,-774.68002)"
       id="a6170-3"
       style="opacity:0.53035147">
      <path
         inkscape:transform-center-y="5.4726862"
         inkscape:transform-center-x="-4.57419"
         transform="matrix(1.5376775,0,0,1.5376775,884.53912,-862.04996)"
         d="m -11,6.5 c 0,5.246705 -4.029437,9.5 -9,9.5 -4.970563,0 -9,-4.253295 -9,-9.5 0,-5.2467051 4.029437,-9.5 9,-9.5 4.970563,0 9,4.2532949 9,9.5 z"
         sodipodi:ry="9.5"
         sodipodi:rx="9"
         sodipodi:cy="6.5"
         sodipodi:cx="-20"
         id="path4334-55-8-8-7"
         style="opacity:0.64536737;fill:url(#radialGradient6160-4);fill-opacity:1;fill-rule:nonzero;stroke:none"
         sodipodi:type="arc" />
    </a>
  </g>
</svg> ]====]
