================
Leda for windows
================

Download LuaDist for windows x86 (http://luadist.org/), unpack LuaDist and unpack
the directories lib and bin of this package into Luadist install directory.